<?php 

  $con="host=localhost port=5436 dbname=practic password= user=postgres";
  $cone=pg_connect($con);

?>